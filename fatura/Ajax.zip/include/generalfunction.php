<?php
Class General_Function
{



}